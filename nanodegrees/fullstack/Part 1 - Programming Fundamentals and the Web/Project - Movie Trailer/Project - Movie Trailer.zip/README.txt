Movie Trailer Website
-------------

Movie Trailer Website is the first project in the Udacity Fullstack 
nanodgree. This document details how to run and update the movies
data structure file 'moviesdb.py' to create a HTML file named movieflix.html
which will dispay all movies. To display the trailer, just click over 
the poster image. 

To build your very first movieflix.html please run the below comman, which 
will automatically open the movieflix.html and display my favor movies.

 python2.7 ./runme.py

To update the movies to be displayed, you will need to edit the moviesdb.py 
file, then run the runme.py.  

 <text editor> ./movies.db 
 