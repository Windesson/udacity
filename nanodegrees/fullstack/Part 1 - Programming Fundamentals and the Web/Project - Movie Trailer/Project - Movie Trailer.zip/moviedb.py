"""
A list of favor movies.
"""
data = [
           {
             "title": "Avatar",
             "poster_image_url": "https://upload.wikimedia.org/wikipedia/en/b/b0/Avatar-Teaser-Poster.jpg",
             "trailer_youtube_url": "https://youtu.be/d1_JBMrrYw8"
           },
                     
           {
             "title": "The Ice Age",
             "poster_image_url": "http://www.gstatic.com/tv/thumb/movieposters/29626/p29626_p_v8_ae.jpg",
             "trailer_youtube_url": "https://youtu.be/cMfeWyVBidk"
           },
            
           {
             "title": "The Matrix",
             "poster_image_url": "http://t0.gstatic.com/images?q=tbn:ANd9GcQq3pIz-aKgkmYX1dJ-EL-AlHSPcOO7wdqRIJ5gJy9qNinXpmle",
             "trailer_youtube_url": "https://youtu.be/3qKmDnJVDjs"
           },
            
           {
             "title": "Braveheart",
             "poster_image_url": "http://www.gstatic.com/tv/thumb/movieposters/16782/p16782_p_v8_al.jpg",
             "trailer_youtube_url": "https://youtu.be/lEOOZDbMrgE"
           }
        ]
         